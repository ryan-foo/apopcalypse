﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour {
    public GameObject Pause;
    //public int splllit = 1;
    public GameController gameController;

    private void Start()
    {
        GameObject gameControllerObject = GameObject.FindWithTag("GameController");
        if (gameControllerObject != null)
        {
            gameController = gameControllerObject.GetComponent<GameController>();
        }
        if (gameController == null)
        {
            Debug.Log("Cannot find 'GameController' script");
        }
    }

    public void PlayGame()
    {
        SceneManager.LoadScene(1);
        Time.timeScale = 1;
    }
    public void QuitGame()
    {
        Debug.Log("QUIT!");
        Application.Quit();
    }
    public void Continue()
    {
        Time.timeScale = 1;
        Pause.SetActive(false);
        gameController.isPaused = false;

    }
    //public void split()
    //{
    //    if (splllit==0)
    //    {
    //        splllit = 1;
    //        Debug.Log(splllit);
    //    }
    //    else
    //    {
    //        splllit = 0;
    //        Debug.Log(splllit);
    //    }
    //}
}
