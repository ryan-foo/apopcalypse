﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MovePlayer : MonoBehaviour
{
    public GameObject bullet;
    public float turnSpeed = 3f;
    bool canShoot;
    private float cooldown = 0.25f;
    private float targetAngle = 0;
    private float testAngle = 0;
    //private float fixangle = 0;
    private float cooldownTimer;

    // Use this for initialization
    void Start()
    {
         }

    void fireBullet(string col)
    {
        //生成子弹
        GameObject b = (GameObject)(Instantiate(bullet, transform.position + transform.up * 1.5f, Quaternion.identity));
        //b.GetComponent<Rigidbody2D>().velocity = 10*(new Vector3(tar.x - Camera.main.pixelWidth / 2, tar.y - Camera.main.pixelHeight / 2, 0).normalized );
        b.GetComponent<Rigidbody2D>().AddForce(transform.up * 1000);//，不跟随鼠标位置


        switch (col)
        {
            case "red":
                b.GetComponent<SpriteRenderer>().color = Color.red;
                b.GetComponent<bullet>().bulletCol = 3;
                break;
            case "blue":
                b.GetComponent<SpriteRenderer>().color = Color.blue;
                b.GetComponent<bullet>().bulletCol = 2;
                break;
            case "yellow":
                b.GetComponent<SpriteRenderer>().color = Color.yellow;
                b.GetComponent<bullet>().bulletCol = 1;
                break;
        }
    }
    
    // Update is called once per frame
    void Update()
    {
 
        //记录鼠标位置
        Vector3 tar = Input.mousePosition;

            // Your firing code
            if (Time.time > cooldownTimer && Input.GetKeyDown(KeyCode.Q)) // Yellow
            {
            cooldownTimer = Time.time + cooldown;
            fireBullet("yellow");
                
            }
            if (Time.time > cooldownTimer && Input.GetKeyDown(KeyCode.W)) // Blue // Change -- Get down
            {
            cooldownTimer = Time.time + cooldown;
            fireBullet("blue");
                
            }
         if (Time.time > cooldownTimer && Input.GetKeyDown(KeyCode.E)) // Red
            {
            cooldownTimer = Time.time + cooldown;
            fireBullet("red");
                

        }

              
        
            Vector3 worldPos = Camera.main.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, -Camera.main.transform.position.z));

            Vector3 direction = worldPos - transform.position;

            direction.z = 0f;

            direction.Normalize();




          testAngle=Mathf.Atan2(direction.y, direction.x) * Mathf.Rad2Deg;
        //float targetAngle = -150; //to test the 0 angle, seems that is from -180 to 180, and certain upward is 0
          testAngle -= 90;
            if (testAngle>90)
        {
            //targetAngle = 75;
            
            Debug.Log(testAngle);//show the angle of the mouse now
            transform.rotation =  Quaternion.Euler(0, 0, 90);

        }
        else if (testAngle < -90)
        {
            //targetAngle = -75;

            transform.rotation = Quaternion.Euler(0, 0, -90);//Quaternion.Slerp(transform.rotation, Quaternion.Euler(0, 0, -75), turnSpeed * Time.deltaTime);
            //we forced it to the angle we want
            //still a lillte bit strange
        }
        else
        {
            targetAngle = testAngle;
            transform.rotation = Quaternion.Slerp(transform.rotation, Quaternion.Euler(0, 0, targetAngle), turnSpeed * Time.deltaTime);

        }



    }
    //void LateUpdate()//something strange
    //{
    //    transform.eulerAngles = new Vector3(
    //         Mathf.Clamp(transform.eulerAngles.y, MinClamp, MaxClamp),
    //         transform.eulerAngles.z,
    //         transform.eulerAngles.x
    //    );
    //}
 
}
