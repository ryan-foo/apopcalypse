﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class MainManuControl : MonoBehaviour
{
    public Button level02Button, level03Button;//设定按钮状态
    int levelPassed;//设定通关变量
                    // Use this for initialization
    void Start()
    {
        levelPassed = PlayerPrefs.GetInt("LevelPassed");
        level02Button.interactable = false;//按钮不可互动
        level03Button.interactable = false;
        switch (levelPassed)
        {
            case 1:
                level02Button.interactable = true;
                break;
            case 2:
                level02Button.interactable = true;
                level03Button.interactable = true;
                break;
        }
    }
    public void levelToLoad(int level)//加载关卡
    {
        SceneManager.LoadScene(level);
    }
    //public void resetPlayerPrefs()
    //{
    //    level02Button.interactable = false;
    //    level03Button.interactable = false;
    //    PlayerPrefs.DeleteAll();
    //}
}
