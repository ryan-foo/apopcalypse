﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class bullet : MonoBehaviour
// add score
{
    #region
    private Color yel;
    private Color blu;
    private Color reeed;
    private Color orang;
    private Color purp;
    private Color gren;
    SpriteRenderer r;
    public int bulletCol; // Determines the color of the bullet. It is created when we press Q W E (yellow, blue, red)
    public int scoreValue;
    private GameController gameController;
    public GameObject Explosion_R;
    public GameObject Explosion_Y;
    public GameObject Explosion_B; // declaring objects for explosions
    #endregion
    //public GameObject Explosion_B; // blue explosion
    //public GameObject Explosion_Y; // yellow explosion
    // for now, all explosions will be red to test.
    private zombie zommm;
    public Sprite nn;
    public Sprite nn1;
    public Sprite nn2;
    public Sprite nn3;
    public Sprite jj;
    public Sprite ss1;
    public Sprite ss2;
    public Sprite ss3;
    public Sprite ss;
    public Sprite bb1;
    public Sprite bb2;
    public Sprite bb3;
    public Sprite bb;
    public Sprite jj1;
    public Sprite jj2;
    public Sprite jj3;
    // Use this for initialization
    void Start()
    {
        GameObject gameControllerObject = GameObject.FindWithTag("GameController");
        if (gameControllerObject != null)
        {
            gameController = gameControllerObject.GetComponent<GameController>();
        }
        if (gameController == null)
        {
            Debug.Log("Cannot find 'GameController' script");
        }
        // Destroy(gameObject, 10);//十秒后消除子弹
        #region
        yel = new Color(255 / 255f, 220 / 255f, 164 / 255f);
        blu = new Color(143 / 255f, 191 / 255f, 216 / 255f);
        reeed = new Color(219 / 255f, 117 / 255f, 117 / 255f);
        //reeed = new Color(219 / 255f, 55 / 255f, 55 / 255f);
        orang = new Color(249 / 255f, 169 / 255f, 115 / 255f);
        //orang = new Color(255 / 255f, 64 / 255f, 35 / 255f);
        purp = new Color(197 / 255f, 171 / 255f, 221 / 255f);
        gren = new Color(163 / 255f, 211 / 255f, 163 / 255f);

        #endregion
    }
    void OnCollisionEnter2D(Collision2D coll)

    { // 1 = Yellow, 2 = Blue, 3 = Red
        //1 done; 2,3 waiting
        if (bulletCol == 1)
        {
            if (coll.gameObject.tag == "zombie")
            {
                if ( coll.gameObject.GetComponent<zombie>().zombCol == 1)
                { // if yellow normal
                    Destroy(coll.gameObject);
                    Destroy(gameObject);
                    Instantiate(Explosion_Y, transform.position, transform.rotation); // creates explosion
                    gameController.AddScore(scoreValue); // adds score

                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 2)
                {
                    if (gameController.splllit == 1)
                    {
                        r = coll.gameObject.GetComponent<SpriteRenderer>();
                        coll.gameObject.tag = "zombie";
                        r.color = gren;
                        coll.gameObject.GetComponent<zombie>().zombCol = 6;
                        Destroy(gameObject);
                    }
                    else
                    {
                        coll.gameObject.GetComponent<SpriteRenderer>().sprite = nn3;
                        coll.gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                        coll.gameObject.tag = "zombie";
                        coll.gameObject.GetComponent<zombie>().zombCol = 6;
                        Destroy(gameObject);
                    }
                   

                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 3)
                {
                    if (gameController.splllit == 1)
                    {
                        r = coll.gameObject.GetComponent<SpriteRenderer>();
                        coll.gameObject.tag = "zombie";
                        r.color = orang;
                        coll.gameObject.GetComponent<zombie>().zombCol = 4;
                        Destroy(gameObject);
                    }
                    else
                    {
                        coll.gameObject.GetComponent<SpriteRenderer>().sprite = nn1;
                        coll.gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                        coll.gameObject.tag = "zombie";
                        coll.gameObject.GetComponent<zombie>().zombCol = 4;
                        Destroy(gameObject);
                    }
                   

                }
                else if ( coll.gameObject.GetComponent<zombie>().zombCol == 4)
                {
                    
                    coll.gameObject.tag = "zombie";
                    coll.gameObject.GetComponent<SpriteRenderer>().sprite = nn;
                    coll.gameObject.GetComponent<SpriteRenderer>().color = reeed;
                    coll.gameObject.GetComponent<zombie>().zombCol = 3;
                    Destroy(gameObject);

                }
                else if ( coll.gameObject.GetComponent<zombie>().zombCol == 6)
                {
                    
                    coll.gameObject.tag = "zombie";
                    coll.gameObject.GetComponent<SpriteRenderer>().sprite = nn;
                    coll.gameObject.GetComponent<SpriteRenderer>().color = blu;
                    coll.gameObject.GetComponent<zombie>().zombCol = 2;
                    Destroy(gameObject);

                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 7)
                {
                    Destroy(coll.gameObject);
                    Destroy(gameObject);
                    Instantiate(Explosion_Y, transform.position, transform.rotation);
                    gameController.AddScore(scoreValue);
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 8)
                {
                    if (gameController.splllit == 1)
                    {
                        r = coll.gameObject.GetComponent<SpriteRenderer>();
                        coll.gameObject.tag = "zombie";
                        r.color = gren;
                        coll.gameObject.GetComponent<zombie>().zombCol = 12;
                        Destroy(gameObject);
                    }
                    else
                    {
                        coll.gameObject.GetComponent<SpriteRenderer>().sprite = ss3;
                        coll.gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                        coll.gameObject.tag = "zombie";
                        coll.gameObject.GetComponent<zombie>().zombCol = 12;
                        Destroy(gameObject);
                    }
                   

                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 9)
                {
                    if (gameController.splllit == 9)
                    {
                        r = coll.gameObject.GetComponent<SpriteRenderer>();
                        coll.gameObject.tag = "zombie";
                        r.color = orang;
                        coll.gameObject.GetComponent<zombie>().zombCol = 10;
                        Destroy(gameObject);
                    }
                    else
                    {
                        coll.gameObject.GetComponent<SpriteRenderer>().sprite = ss1;
                        coll.gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                        coll.gameObject.tag = "zombie";
                        coll.gameObject.GetComponent<zombie>().zombCol = 10;
                        Destroy(gameObject);
                    }
                    
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 10)
                {
                   
                    coll.gameObject.tag = "zombie";
                    coll.gameObject.GetComponent<SpriteRenderer>().sprite = ss;
                    coll.gameObject.GetComponent<SpriteRenderer>().color = reeed;
                    coll.gameObject.GetComponent<zombie>().zombCol = 9;
                    Destroy(gameObject);

                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 12)
                {

                    coll.gameObject.tag = "zombie";
                    coll.gameObject.GetComponent<SpriteRenderer>().sprite = ss;
                    coll.gameObject.GetComponent<SpriteRenderer>().color = blu;
                    coll.gameObject.GetComponent<zombie>().zombCol = 8;
                    Destroy(gameObject);

                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 13)
                {
                    Destroy(coll.gameObject);
                    Destroy(gameObject);
                    Instantiate(Explosion_Y, transform.position, transform.rotation);
                    gameController.AddScore(scoreValue);
                    //score ++
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 14)
                {
                    if (gameController.splllit == 1)
                    {
                        r = coll.gameObject.GetComponent<SpriteRenderer>();
                        coll.gameObject.tag = "zombie";
                        r.color = gren;
                        coll.gameObject.GetComponent<zombie>().zombCol = 18;
                        Destroy(gameObject);
                    }
                    else
                    {
                        coll.gameObject.GetComponent<SpriteRenderer>().sprite = bb3;
                        coll.gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                        coll.gameObject.tag = "zombie";
                        coll.gameObject.GetComponent<zombie>().zombCol = 18;
                        Destroy(gameObject);
                    }                 

                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 15)
                {
                    if (gameController.splllit == 1)
                    {
                        r = coll.gameObject.GetComponent<SpriteRenderer>();
                        coll.gameObject.tag = "zombie";
                        r.color = orang;
                        coll.gameObject.GetComponent<zombie>().zombCol = 16;
                        Destroy(gameObject);
                    }
                    else
                    {
                        coll.gameObject.GetComponent<SpriteRenderer>().sprite = bb1;
                        coll.gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                        coll.gameObject.tag = "zombie";
                        coll.gameObject.GetComponent<zombie>().zombCol = 16;
                        Destroy(gameObject);
                    }
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 16)
                {
                   
                    coll.gameObject.tag = "zombie";
                    coll.gameObject.GetComponent<SpriteRenderer>().sprite = bb;
                    coll.gameObject.GetComponent<SpriteRenderer>().color = reeed;
                    coll.gameObject.GetComponent<zombie>().zombCol = 15;
                    Destroy(gameObject);

                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 18)
                {
                    
                    coll.gameObject.tag = "zombie";
                    coll.gameObject.GetComponent<SpriteRenderer>().sprite = bb;
                    coll.gameObject.GetComponent<SpriteRenderer>().color = blu;
                    coll.gameObject.GetComponent<zombie>().zombCol = 14;
                    Destroy(gameObject);

                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 19)
                {
                    Destroy(coll.gameObject);
                    Destroy(gameObject);
                    Instantiate(Explosion_Y, transform.position, transform.rotation);
                    gameController.AddScore(scoreValue);
                    //score ++
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 20)
                {
                    if (gameController.splllit == 1)
                    {
                        r = coll.gameObject.GetComponent<SpriteRenderer>();
                        coll.gameObject.tag = "zombie";
                        r.color = gren;
                        coll.gameObject.GetComponent<zombie>().zombCol = 24;
                        Destroy(gameObject);

                    }
                    else
                    {
                        coll.gameObject.GetComponent<SpriteRenderer>().sprite = jj3;
                        coll.gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                        coll.gameObject.tag = "zombie";
                        coll.gameObject.GetComponent<zombie>().zombCol = 24;
                        Destroy(gameObject);
                    }
                   
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 21)
                {
                    if (gameController.splllit == 1)
                    {
                        r = coll.gameObject.GetComponent<SpriteRenderer>();
                        coll.gameObject.tag = "zombie";
                        r.color = orang;
                        coll.gameObject.GetComponent<zombie>().zombCol = 22;
                        Destroy(gameObject);

                    }
                    else
                    {
                        coll.gameObject.GetComponent<SpriteRenderer>().sprite = jj1;
                        coll.gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                        coll.gameObject.tag = "zombie";
                        coll.gameObject.GetComponent<zombie>().zombCol = 22;
                        Destroy(gameObject);
                    }

                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 22)
                {
                   
                    coll.gameObject.tag = "zombie";
                    coll.gameObject.GetComponent<SpriteRenderer>().sprite = jj;
                    coll.gameObject.GetComponent<SpriteRenderer>().color = reeed;
                    coll.gameObject.GetComponent<zombie>().zombCol = 21;
                    Destroy(gameObject);

                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 24)
                {
                    coll.gameObject.tag = "zombie";
                    coll.gameObject.GetComponent<SpriteRenderer>().sprite = jj;
                    coll.gameObject.GetComponent<SpriteRenderer>().color = blu;
                    coll.gameObject.GetComponent<zombie>().zombCol = 20;
                    Destroy(gameObject);

                }
                else 
                {
                    Destroy(gameObject);
                }
            }
            
            
        }

        if (bulletCol == 2)
        {
            if (coll.gameObject.tag == "zombie" )
            {
                if (coll.gameObject.GetComponent<zombie>().zombCol == 2)
                {
                    Destroy(coll.gameObject);
                    Destroy(gameObject);
                    Instantiate(Explosion_B, transform.position, transform.rotation);
                    gameController.AddScore(scoreValue);
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 1)
                {
                    if (gameController.splllit == 1)
                    {
                        r = coll.gameObject.GetComponent<SpriteRenderer>();
                        coll.gameObject.tag = "zombie";
                        r.color = gren;
                        coll.gameObject.GetComponent<zombie>().zombCol = 6;
                        Destroy(gameObject);
                    }
                    else
                    {
                        coll.gameObject.GetComponent<SpriteRenderer>().sprite = nn3;
                        coll.gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                        coll.gameObject.tag = "zombie";
                        coll.gameObject.GetComponent<zombie>().zombCol = 6;
                        Destroy(gameObject);
                    }
                    
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 3)
                {
                    if (gameController.splllit == 1)
                    {
                        r = coll.gameObject.GetComponent<SpriteRenderer>();
                        coll.gameObject.tag = "zombie";
                        r.color = purp;
                        coll.gameObject.GetComponent<zombie>().zombCol = 5;
                        Destroy(gameObject);
                    }
                    else
                    {
                        coll.gameObject.GetComponent<SpriteRenderer>().sprite = nn2;
                        coll.gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                        coll.gameObject.tag = "zombie";
                        coll.gameObject.GetComponent<zombie>().zombCol = 5;
                        Destroy(gameObject);
                    }
                   
                }
                else if ( coll.gameObject.GetComponent<zombie>().zombCol == 5)
                {
                    coll.gameObject.tag = "zombie";
                    coll.gameObject.GetComponent<SpriteRenderer>().sprite = nn;
                    coll.gameObject.GetComponent<SpriteRenderer>().color = reeed;
                    coll.gameObject.GetComponent<zombie>().zombCol = 3;
                    Destroy(gameObject);

                }
               else if (coll.gameObject.GetComponent<zombie>().zombCol == 6)
                {
                    coll.gameObject.tag = "zombie";
                    coll.gameObject.GetComponent<SpriteRenderer>().sprite = nn;
                    coll.gameObject.GetComponent<SpriteRenderer>().color = yel;
                    coll.gameObject.GetComponent<zombie>().zombCol = 1;
                    Destroy(gameObject);
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 7)
                {
                    if (gameController.splllit == 1)
                    {
                        r = coll.gameObject.GetComponent<SpriteRenderer>();
                        coll.gameObject.tag = "zombie";
                        r.color = gren;
                        coll.gameObject.GetComponent<zombie>().zombCol = 12;
                        Destroy(gameObject);
                    }
                    else
                    {
                        coll.gameObject.GetComponent<SpriteRenderer>().sprite = ss3;
                        coll.gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                        coll.gameObject.tag = "zombie";
                        coll.gameObject.GetComponent<zombie>().zombCol = 12;
                        Destroy(gameObject);
                    }

                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 8)
                {
                    Destroy(coll.gameObject);
                    Destroy(gameObject);
                    Instantiate(Explosion_B, transform.position, transform.rotation);
                    gameController.AddScore(scoreValue);
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 9)
                {
                    if (gameController.splllit == 1)
                    {
                        r = coll.gameObject.GetComponent<SpriteRenderer>();
                        coll.gameObject.tag = "zombie";
                        r.color = purp;
                        coll.gameObject.GetComponent<zombie>().zombCol = 11;
                        Destroy(gameObject);
                    }
                    else
                    {
                        coll.gameObject.GetComponent<SpriteRenderer>().sprite = ss2;
                        coll.gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                        coll.gameObject.tag = "zombie";
                        coll.gameObject.GetComponent<zombie>().zombCol = 11;
                        Destroy(gameObject);
                    }
                  

                }
                else if ( coll.gameObject.GetComponent<zombie>().zombCol == 11)
                {
                    coll.gameObject.tag = "zombie";
                    coll.gameObject.GetComponent<SpriteRenderer>().sprite = ss;
                    coll.gameObject.GetComponent<SpriteRenderer>().color = reeed;
                    coll.gameObject.GetComponent<zombie>().zombCol = 9;
                    Destroy(gameObject);

                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 12)
                {
                    coll.gameObject.tag = "zombie";
                    coll.gameObject.GetComponent<SpriteRenderer>().sprite = ss;
                    coll.gameObject.GetComponent<SpriteRenderer>().color = yel;
                    coll.gameObject.GetComponent<zombie>().zombCol = 7;
                    Destroy(gameObject);

                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 13)
                {
                    if (gameController.splllit == 1)
                    {
                        r = coll.gameObject.GetComponent<SpriteRenderer>();
                        coll.gameObject.tag = "zombie";
                        r.color = gren;
                        coll.gameObject.GetComponent<zombie>().zombCol = 18;
                        Destroy(gameObject);
                    }
                    else
                    {
                        coll.gameObject.GetComponent<SpriteRenderer>().sprite = bb3;
                        coll.gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                        coll.gameObject.tag = "zombie";
                        coll.gameObject.GetComponent<zombie>().zombCol = 18;
                        Destroy(gameObject);
                    }

                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 14)
                {
                    Destroy(coll.gameObject);
                    Destroy(gameObject);
                    Instantiate(Explosion_B, transform.position, transform.rotation);
                    gameController.AddScore(scoreValue);
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 15)
                {
                    if (gameController.splllit == 1)
                    {
                        r = coll.gameObject.GetComponent<SpriteRenderer>();
                        coll.gameObject.tag = "zombie";
                        r.color = purp;
                        coll.gameObject.GetComponent<zombie>().zombCol = 17;
                        Destroy(gameObject);
                    }
                    else
                    {
                        coll.gameObject.GetComponent<SpriteRenderer>().sprite = bb2;
                        coll.gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                        coll.gameObject.tag = "zombie";
                        coll.gameObject.GetComponent<zombie>().zombCol = 17;
                        Destroy(gameObject);
                    }
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 17)
                {
                    coll.gameObject.tag = "zombie";
                    coll.gameObject.GetComponent<SpriteRenderer>().sprite = bb;
                    coll.gameObject.GetComponent<SpriteRenderer>().color = reeed;
                    coll.gameObject.GetComponent<zombie>().zombCol = 15;
                    Destroy(gameObject);
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 18)
                {
                    coll.gameObject.tag = "zombie";
                    coll.gameObject.GetComponent<SpriteRenderer>().sprite = bb;
                    coll.gameObject.GetComponent<SpriteRenderer>().color = yel;
                    coll.gameObject.GetComponent<zombie>().zombCol = 13;
                    Destroy(gameObject);

                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 19)
                {
                    if (gameController.splllit == 1)
                    {
                        r = coll.gameObject.GetComponent<SpriteRenderer>();
                        coll.gameObject.tag = "zombie";
                        r.color = gren;
                        coll.gameObject.GetComponent<zombie>().zombCol = 24;
                        Destroy(gameObject);
                    }
                    else
                    {
                        coll.gameObject.GetComponent<SpriteRenderer>().sprite = jj3;
                        coll.gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                        coll.gameObject.tag = "zombie";
                        coll.gameObject.GetComponent<zombie>().zombCol = 24;
                        Destroy(gameObject);
                    }
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 20)
                {
                    Destroy(coll.gameObject);
                    Destroy(gameObject);
                    Instantiate(Explosion_B, transform.position, transform.rotation);
                    gameController.AddScore(scoreValue);
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 21)
                {
                    if (gameController.splllit == 1)
                    {
                        r = coll.gameObject.GetComponent<SpriteRenderer>();
                        coll.gameObject.tag = "zombie";
                        r.color = purp;
                        coll.gameObject.GetComponent<zombie>().zombCol = 23;
                        Destroy(gameObject);
                    }
                    else
                    {
                        coll.gameObject.GetComponent<SpriteRenderer>().sprite = jj2;
                        coll.gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                        coll.gameObject.tag = "zombie";
                        coll.gameObject.GetComponent<zombie>().zombCol = 23;
                        Destroy(gameObject);
                    }
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 23)
                {
                    coll.gameObject.tag = "zombie";
                    coll.gameObject.GetComponent<SpriteRenderer>().sprite = jj;
                    coll.gameObject.GetComponent<SpriteRenderer>().color = reeed;
                    coll.gameObject.GetComponent<zombie>().zombCol = 21;
                    Destroy(gameObject);

                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 24)
                {
                    coll.gameObject.tag = "zombie";
                    coll.gameObject.GetComponent<SpriteRenderer>().sprite = jj;
                    coll.gameObject.GetComponent<SpriteRenderer>().color = yel;
                    coll.gameObject.GetComponent<zombie>().zombCol = 19;
                    Destroy(gameObject);

                }
                else
                {
                    Destroy(gameObject);
                }
            }
           
        }

        if (bulletCol == 3)
        {
            if(coll.gameObject.tag == "zombie")
            {
                if (coll.gameObject.GetComponent<zombie>().zombCol == 3)
                {
                    Destroy(coll.gameObject);
                    Destroy(gameObject);
                    Instantiate(Explosion_R, transform.position, transform.rotation);
                    gameController.AddScore(scoreValue);
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 1)
                {
                    if (gameController.splllit == 1)
                    {
                        r = coll.gameObject.GetComponent<SpriteRenderer>();
                        coll.gameObject.tag = "zombie";
                        r.color = orang;
                        coll.gameObject.GetComponent<zombie>().zombCol = 4;
                        Destroy(gameObject);
                    }
                    else
                    {
                        coll.gameObject.GetComponent<SpriteRenderer>().sprite = nn1;
                        coll.gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                        coll.gameObject.tag = "zombie";
                        coll.gameObject.GetComponent<zombie>().zombCol = 4;
                        Destroy(gameObject);
                    }
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 2)
                {
                    if (gameController.splllit == 1)
                    {
                        r = coll.gameObject.GetComponent<SpriteRenderer>();
                        coll.gameObject.tag = "zombie";
                        r.color = purp;
                        coll.gameObject.GetComponent<zombie>().zombCol = 5;
                        Destroy(gameObject);
                    }
                    else
                    {
                        coll.gameObject.GetComponent<SpriteRenderer>().sprite = nn2;
                        coll.gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                        coll.gameObject.tag = "zombie";
                        coll.gameObject.GetComponent<zombie>().zombCol = 5;
                        Destroy(gameObject);
                    }
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 4)
                {
                    coll.gameObject.tag = "zombie";
                    coll.gameObject.GetComponent<SpriteRenderer>().sprite = nn;
                    coll.gameObject.GetComponent<SpriteRenderer>().color = yel;
                    coll.gameObject.GetComponent<zombie>().zombCol = 1;
                    Destroy(gameObject);
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 5)
                {
                    coll.gameObject.tag = "zombie";
                    coll.gameObject.GetComponent<SpriteRenderer>().sprite = nn;
                    coll.gameObject.GetComponent<SpriteRenderer>().color = blu;
                    coll.gameObject.GetComponent<zombie>().zombCol = 2;
                    Destroy(gameObject);
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 7)
                {
                    if (gameController.splllit == 1)
                    {
                        r = coll.gameObject.GetComponent<SpriteRenderer>();
                        coll.gameObject.tag = "zombie";
                        r.color = orang;
                        coll.gameObject.GetComponent<zombie>().zombCol = 10;
                        Destroy(gameObject);
                    }
                    else
                    {
                        coll.gameObject.GetComponent<SpriteRenderer>().sprite = ss1;
                        coll.gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                        coll.gameObject.tag = "zombie";
                        coll.gameObject.GetComponent<zombie>().zombCol = 10;
                        Destroy(gameObject);
                    }
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 8)
                {
                    if (gameController.splllit == 1)
                    {
                        r = coll.gameObject.GetComponent<SpriteRenderer>();
                        coll.gameObject.tag = "zombie";
                        r.color = purp;
                        coll.gameObject.GetComponent<zombie>().zombCol = 11;
                        Destroy(gameObject);
                    }
                    else
                    {
                        coll.gameObject.GetComponent<SpriteRenderer>().sprite = ss2;
                        coll.gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                        coll.gameObject.tag = "zombie";
                        coll.gameObject.GetComponent<zombie>().zombCol = 11;
                        Destroy(gameObject);
                    }
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 9)
                {
                    Destroy(coll.gameObject);
                    Destroy(gameObject);
                    Instantiate(Explosion_R, transform.position, transform.rotation);
                    gameController.AddScore(scoreValue);
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 10)
                {
                    coll.gameObject.tag = "zombie";
                    coll.gameObject.GetComponent<SpriteRenderer>().sprite = ss;
                    coll.gameObject.GetComponent<SpriteRenderer>().color = yel;
                    coll.gameObject.GetComponent<zombie>().zombCol = 7;
                    Destroy(gameObject);

                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 11)
                {
                    coll.gameObject.tag = "zombie";
                    coll.gameObject.GetComponent<SpriteRenderer>().sprite = ss;
                    coll.gameObject.GetComponent<SpriteRenderer>().color = blu;
                    coll.gameObject.GetComponent<zombie>().zombCol = 8;
                    Destroy(gameObject);

                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 13)
                {
                    if (gameController.splllit == 1)
                    {
                        r = coll.gameObject.GetComponent<SpriteRenderer>();
                        coll.gameObject.tag = "zombie";
                        r.color = orang;
                        coll.gameObject.GetComponent<zombie>().zombCol = 16;
                        Destroy(gameObject);
                    }
                    else
                    {
                        coll.gameObject.GetComponent<SpriteRenderer>().sprite = bb1;
                        coll.gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                        coll.gameObject.tag = "zombie";
                        coll.gameObject.GetComponent<zombie>().zombCol = 16;
                        Destroy(gameObject);
                    }
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 14)
                {
                    if (gameController.splllit == 1)
                    {
                        r = coll.gameObject.GetComponent<SpriteRenderer>();
                        coll.gameObject.tag = "zombie";
                        r.color = purp;
                        coll.gameObject.GetComponent<zombie>().zombCol = 17;
                        Destroy(gameObject);
                    }
                    else
                    {
                        coll.gameObject.GetComponent<SpriteRenderer>().sprite = bb2;
                        coll.gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                        coll.gameObject.tag = "zombie";
                        coll.gameObject.GetComponent<zombie>().zombCol = 17;
                        Destroy(gameObject);
                    }
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 15)
                {
                    Destroy(coll.gameObject);
                    Destroy(gameObject);
                    Instantiate(Explosion_R, transform.position, transform.rotation);
                    gameController.AddScore(scoreValue);
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 16)
                {
                    coll.gameObject.tag = "zombie";
                    coll.gameObject.GetComponent<SpriteRenderer>().sprite = bb;
                    coll.gameObject.GetComponent<SpriteRenderer>().color = yel;
                    coll.gameObject.GetComponent<zombie>().zombCol = 13;
                    Destroy(gameObject);
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 17)
                {
                    coll.gameObject.tag = "zombie";
                    coll.gameObject.GetComponent<SpriteRenderer>().sprite = bb;
                    coll.gameObject.GetComponent<SpriteRenderer>().color = blu;
                    coll.gameObject.GetComponent<zombie>().zombCol = 14;
                    Destroy(gameObject);
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 19)
                {
                    if (gameController.splllit == 1)
                    {
                        r = coll.gameObject.GetComponent<SpriteRenderer>();
                        coll.gameObject.tag = "zombie";
                        r.color = orang;
                        coll.gameObject.GetComponent<zombie>().zombCol = 22;
                        Destroy(gameObject);
                    }
                    else
                    {
                        coll.gameObject.GetComponent<SpriteRenderer>().sprite = jj1;
                        coll.gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                        coll.gameObject.tag = "zombie";
                        coll.gameObject.GetComponent<zombie>().zombCol = 22;
                        Destroy(gameObject);
                    }
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 20)
                {
                    if (gameController.splllit == 1)
                    {
                        r = coll.gameObject.GetComponent<SpriteRenderer>();
                        coll.gameObject.tag = "zombie";
                        r.color = purp;
                        coll.gameObject.GetComponent<zombie>().zombCol = 23;
                        Destroy(gameObject);
                    }
                    else
                    {
                        coll.gameObject.GetComponent<SpriteRenderer>().sprite = jj2;
                        coll.gameObject.GetComponent<SpriteRenderer>().color = Color.white;
                        coll.gameObject.tag = "zombie";
                        coll.gameObject.GetComponent<zombie>().zombCol = 23;
                        Destroy(gameObject);
                    }
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 21)
                {
                    Destroy(coll.gameObject);
                    Destroy(gameObject);
                    Instantiate(Explosion_R, transform.position, transform.rotation);
                    gameController.AddScore(scoreValue);
                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 22)
                {
                    coll.gameObject.tag = "zombie";
                    coll.gameObject.GetComponent<SpriteRenderer>().sprite = jj;
                    coll.gameObject.GetComponent<SpriteRenderer>().color = yel;
                    coll.gameObject.GetComponent<zombie>().zombCol = 19;
                    Destroy(gameObject);

                }
                else if (coll.gameObject.GetComponent<zombie>().zombCol == 23)
                {
                    coll.gameObject.tag = "zombie";
                    coll.gameObject.GetComponent<SpriteRenderer>().sprite = jj;
                    coll.gameObject.GetComponent<SpriteRenderer>().color = blu;
                    coll.gameObject.GetComponent<zombie>().zombCol = 20;
                    Destroy(gameObject);

                }
                else
                {
                    Destroy(gameObject);
                }
            }
        }
            
    }
        // Update is called once per frame
        void Update () {
		
	}
}
