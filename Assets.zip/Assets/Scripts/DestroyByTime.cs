﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyByTime : MonoBehaviour
{
    public float lifetime; // Object will set its lifetime, and destroy itself when time is up.
                           // This will be useful for cleaning up blood of zombie etc.

    void Start()
    {
        Destroy(gameObject, lifetime);
    }

}