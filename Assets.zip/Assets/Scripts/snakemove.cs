﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class snakemove : MonoBehaviour {
    Rigidbody2D m_Rigidbody;
    public int count;
    float m_Speed;
    private float snake = 0;
    private float t = 0;
    public int zombCol; // declare a new public int zombCol which determines the color of the zombie
    //public Color orange = new Color(1.0F, 0.64F, 0.0F);
    //public Color purple = new Color(0.45F, 0.54F, 0.48F); trying to define new colors
    public Rigidbody rb;
    // Use this for initialization
    void Start()
    {
        m_Rigidbody = GetComponent<Rigidbody2D>();
        //Set the speed of the GameObject
        m_Speed = 0.3f;//the speed of test zombie move
        rb = GetComponent<Rigidbody>();

        zombCol = Random.Range(1, 7);
        #region
        //need change?
        // 1 - Yellow
        // 2 - Blue
        // 3 - Red
        // 4 - Orange (grey)
        // 5 - Purple (magenta)
        // 6 - Green
        // Deciding zombie colors //why 7?
        #endregion

        switch (zombCol)
        {
            case 1:
                GetComponent<SpriteRenderer>().color = Color.yellow;
                break;
            case 2:
                GetComponent<SpriteRenderer>().color = Color.blue;
                break;
            case 3:
                GetComponent<SpriteRenderer>().color = Color.red;
                break;
            case 4:
                GetComponent<SpriteRenderer>().color = Color.grey;
                break;
            case 5:
                GetComponent<SpriteRenderer>().color = Color.magenta;
                break;
            case 6:
                GetComponent<SpriteRenderer>().color = Color.green;
                break;
        }


        

         }
         

    
    void OnCollisionEnter2D(Collision2D coll)

    {
        if (coll.gameObject.tag == "block")
        {
            Destroy(coll.gameObject);
            Destroy(gameObject);
        }
        if (coll.gameObject.tag == "finalblock")
        {
            coll.gameObject.SetActive(false);

        }
    }
    // Update is called once per frame
    void Update()
    {
        t = Time.time;
       
        snake = Mathf.Sin(t);
          
      m_Rigidbody.velocity = -transform.up * m_Speed + transform.right * snake;//downwards+rightwards
        //rb.AddForce(transform.forward * snake*10);
    }
 
}
