﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;



public class box : MonoBehaviour {
   
    
	// Use this for initialization
	void Start () {
       
     	}
    void OnCollisionEnter2D(Collision2D coll)

    {
        if (coll.gameObject.tag == "block")
        {
            Destroy(coll.gameObject);
            Destroy(gameObject);
        }
    }
    // Update is called once per frame
    void Update () {
		
	}
}
