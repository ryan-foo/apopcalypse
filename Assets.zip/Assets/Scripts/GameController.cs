﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GameController : MonoBehaviour
{
    public GameObject zombie; // Calling the zombie GameObject to be spawned
    public GameObject snake;
    //public GameObject red;
    //public GameObject yellow;
    //public GameObject orange;
    //public GameObject blue;
    public Vector3 spawnValues; // To initialise where exactly the zombies spawn
    public int zombieCount; // Holds the number of times we cycle through the loop. We set this value in inspector in Unity
    private float spawnWait; // How long before we wait before spawning a new zombie
    public float startWait; // Short pause for players to be ready
    private float waveWait; // Short pause between every wave
    public Text loseText; // Lose Text
    public Text scoreText; // Score Text
    public Text levelText; // Level Text 
    public int score; // keeping score in GameController, allowing it to be accessed by all scripts
    //including zombie so we can limit which ones are spawned
    private int level; // showing level
    public GameObject Pause;
    // private double x;
    public void Continue()
    {
        Time.timeScale = 1;
    }
    void Start()
    {
        score = 0;
        zombieCount = 5;
        spawnWait = 1.5f;
        waveWait = 2.0f;
        StartCoroutine(SpawnWaves()); // We have to call Spawn Waves when the game starts. Coroutine so it doesnt pause the game
        UpdateScore();
        loseText.text = "";
        {




        }
    }
    void Update()
    { // adaptive difficulty changes
        if (score < 15)
        {
            zombieCount = 8;
            spawnWait = 1.5f;
            level = 1;
        }
        else if (score > 14 && score < 25)
        {
            zombieCount = 8;
            spawnWait = 1.5f;
            level = 2;
        }
        else if (score > 24 && score < 39)
        {
            zombieCount = 8;
            spawnWait = 1.5f;
            level = 3;
        }
        else if (score > 39 && score < 50)
        {
            zombieCount = 8;
            spawnWait = 1.4f;
            level = 4;
        }
        else if (score > 49 && score < 65)
        {
            zombieCount = 8;
            spawnWait = 1.2f;
            level = 5;
        }
        else if (score > 64 && score < 75)
        {
            zombieCount = 7;
            spawnWait = 1.1f;
            level = 6;
        }
        else if (score > 74 && score < 100)
        {
            zombieCount = 5;
            spawnWait = 1.0f;
            level = 7;
        }
        else if (score > 99 && score < 125)
        {
            zombieCount = 5;
            spawnWait = 0.9f;
            level = 8;
        }
        else if (score > 124 && score < 150)
        {
            zombieCount = 5;
            spawnWait = 0.8f;
            level = 9;
        }
        else if (score > 149)
        {
            zombieCount = 5;
            spawnWait = 0.8f;
            level = 10;
        }


        if (Input.GetKeyDown(KeyCode.Escape))
        {
            Pause.SetActive(true);
            Time.timeScale = 0;
            
        }
    }
   


    IEnumerator SpawnWaves() // Function to spawn waves, Coroutine
    {
        yield return new WaitForSeconds(startWait);
        while (true)
        {
            for (int i = 0; i < zombieCount; i++)
            {
                Vector3 spawnPosition = new Vector3(Random.Range(-spawnValues.x, spawnValues.x), spawnValues.y, spawnValues.z);
                // Attached to the game controller object, 
                Quaternion spawnRotation = Quaternion.identity;
                    Instantiate(zombie, spawnPosition, spawnRotation); // Creates a new zombie at the location
                //if (i == 3)
                //{
                //    Instantiate(snake, spawnPosition, spawnRotation);
                //}
                yield return new WaitForSeconds(spawnWait);
            }
            yield return new WaitForSeconds(waveWait);
        }
        }

    public void AddScore(int NewScoreValue)
    {
        score += NewScoreValue;
        UpdateScore(); // whenevr it's called, add a new score, and update the score
    }

    void UpdateScore()
    {
        scoreText.text = "Score: " + score; // updates the text score on the main game scene
        levelText.text = "Level: " + level; // updates the text level on the main game scene
    }

}

