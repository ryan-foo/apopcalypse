﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine.UI;
using UnityEngine;
using UnityEngine.SceneManagement;


public class gameover : MonoBehaviour
{
    public Text losegame;
    public GameObject GO;
    public GameObject Mainmenu;
    // Use this for initialization
    void Start()
    {
        losegame.text = "";
    }
    void OnCollisionEnter2D(Collision2D coll)

    {
        if (coll.gameObject.tag == "zombie")
        {
            Destroy(coll.gameObject);
            //losegame.text = "Game Over";
            Debug.Log("Disable: " + GO.name);
            Stopplayer();
            
        }
    }
    public void PlayGame()
    {
        SceneManager.LoadScene(0);
    }
    void Stopplayer()
    {
        GO.SetActive(false);
        Mainmenu.SetActive(true);//Mainmenu means the game over scene
    }
    // Update is called once per frame
    void Update()
    {

    }
}
