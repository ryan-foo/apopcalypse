﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class zombie : MonoBehaviour {
    Rigidbody2D m_Rigidbody;
    public int count;
    float m_Speed;
    float acc;
    private float snake=0;
    bool snakemoove = true;
    //private float cd = 0.5f;
    private float t = 0;
    private float p = 0;
    public int zombCol; // declare a new public int zombCol which determines the color of the zombie
    //public Color orange = new Color(1.0F, 0.64F, 0.0F);
    //public Color purple = new Color(0.45F, 0.54F, 0.48F); trying to define new colors
    public Rigidbody rb;
    public Image monster;
    public Sprite snaaake;
    public Sprite snaaakes1;
    public Sprite snaaakes2;
    public Sprite snaaakes3;
    //public Sprite snaaake_blue;
    //public Sprite snaaake_red;
    //public Sprite snaaake_orange;
    //public Sprite snaaake_purple;
    //public Sprite snaaake_green;
    public Sprite normal;
    public Sprite normals1;
    public Sprite normals2;
    public Sprite normals3;
    //    public Sprite normal_blue;
    //  public Sprite normal_red;
    //public Sprite normal_orange;
    //public Sprite normal_purple;
    //public Sprite normal_green;
    public Sprite jet;
    public Sprite jets1;
    public Sprite jets2;
    public Sprite jets3;
    //public Sprite jet_blue;
    //public Sprite jet_red;
    public Sprite balloon;
    public Sprite balloons1;
    public Sprite balloons2;
    public Sprite balloons3;
    private Color yel;
    private Color blu;
    private Color reeed;
    private Color orang;
    private Color purp;
    private Color gren;
    private GameController gameController;

    int RBY_n;
    int OGP_n;
    int RBY_s;
    int OGP_s;
    int RBY_b;
    int OGP_b;
    int RBY_j;
    int OGP_j;

    private float snake_Base_Speed; // declares a different base speed for snakes
    private float balloon_Base_Speed; // declares a different base speed for balloons
    private float jet_Base_Speed; // declares a different base speed for jets
        // Use this for initialization
    void Start()
    {
        acc = 0;
        // points to the GameController
        GameObject gameControllerObject = GameObject.FindWithTag("GameController");
        if (gameControllerObject != null)
        {
            gameController = gameControllerObject.GetComponent<GameController>();
        }
        if (gameController == null)
        {
            Debug.Log("Cannot find 'GameController' script");
        }

        m_Rigidbody = GetComponent<Rigidbody2D>();
        //Set the speed of the GameObject
        m_Speed = 0.5f;//the speed of test zombie move
        rb = GetComponent<Rigidbody>();



        // Dynamic difficulty adjustment. Makes a call to gamecontroller object, which contains score as a public int.
        // If score is less than 15, only build red, blue, yellow zombies, and so on.
        // m_Speed refers to movement speed of the zombies. Should scale based on the zombie.

        RBY_n = Random.Range(1, 4); // red blue yellow normals
        OGP_n = Random.Range(4, 7); // orange green purple normals
        RBY_s = Random.Range(7, 10); // red blue yellow snakes
        OGP_s = Random.Range(10, 13); // orange green purple snakes
        RBY_b = Random.Range(13, 16); // red blue yellow balloons
        OGP_b = Random.Range(16, 19); // orange green purple balloons
        RBY_j = Random.Range(19, 22); // red blue yellow jets
        OGP_j = Random.Range(22, 25); // orange green purple jets

        #region
        if (gameController.score < 5)
        {
            // idea of choosing which zombies to spawn
            // samples from an array created
            // 
       
             zombCol = Random.Range(1, 4);
            m_Speed = 0.3f;
        }
        else if (gameController.score > 4 && gameController.score < 15)
        {
            zombCol = Random.Range(1, 4);
            m_Speed = 0.6f;
        }
        else if (gameController.score > 14 && gameController.score < 25)
        {
            zombCol = Random.Range(1, 7);
            m_Speed = 0.6f;
        }
        else if (gameController.score > 24 && gameController.score < 40)
        {
            zombCol = Random.Range(1, 13);
            m_Speed = 0.6f;
        }
        else if (gameController.score > 39 && gameController.score < 50)
        {
            zombCol = Random.Range(1, 19);
            m_Speed = 0.7f;
        }
        else if (gameController.score > 49 && gameController.score < 70)
        {
            zombCol = Random.Range(1, 25);
            m_Speed = 0.7f;
        }
        else if (gameController.score > 69 && gameController.score < 100)
        {
            zombCol = Random.Range(1, 25);
            m_Speed = 0.7f;
        }
        else if (gameController.score > 99 && gameController.score < 125)
        {
            zombCol = Random.Range(1, 25);
            m_Speed = 0.9f;
        }
        else if (gameController.score > 124 && gameController.score < 150)
        {
            zombCol = Random.Range(1, 25);
            m_Speed = 1.0f;
        }
        else if (gameController.score > 149)
        {
            zombCol = Random.Range(1, 25);
            m_Speed = 1.0f;
        }
        else { }
        #endregion
        
            // 70% normal zombies, 30% jets
            // array with 10 slots
            // 7 are filled with regular zombies, 30% with jets
            //random 0 - 10 in that array
            // automatically a 70% chance

            // if you want to have 70% zombies, 30% jets
            // random 1-100
            // if 1-20, then zombCol = 10
            // if 21-40, then zombCol = 8
            // if 41-60, zombCol = 7

            //Our image component is the one attached to this gameObject.
        #region
            //need change?
            // 1 - Yellow
            // 2 - Blue
            // 3 - Red
            // 4 - Orange (grey)
            // 5 - Purple (magenta)
            // 6 - Green
            // Deciding zombie colors //why 7?
            #endregion
        yel = new Color(255 / 255f, 220 / 255f, 164 / 255f);
        blu = new Color(143 / 255f, 191 / 255f, 216 / 255f);
        reeed = new Color(219 / 255f, 117 / 255f, 117 / 255f);
        //reeed = new Color(219 / 255f, 0 / 255f, 0 / 255f);
        orang = new Color(249 / 255f, 169 / 255f, 115 / 255f);
        //orang = new Color(255 / 255f, 64 / 255f, 35 / 255f);
        purp = new Color(197 / 255f, 171 / 255f, 221 / 255f);
        gren = new Color(163 / 255f, 211 / 255f, 163 / 255f);

        // orange and yellow made more distinct



        switch (zombCol)
        {
            case 1:
                GetComponent<SpriteRenderer>().sprite = normal;
                GetComponent<SpriteRenderer>().color = yel;
                //Debug.Log("dingidng");
                break;
            case 2:
                GetComponent<SpriteRenderer>().sprite = normal;
                GetComponent<SpriteRenderer>().color = blu;
                //Debug.Log("dingidng");
                break;
            case 3:
                GetComponent<SpriteRenderer>().sprite = normal;
                GetComponent<SpriteRenderer>().color = reeed;
                //Debug.Log("dingidng");
                break;
            case 4:
                if (gameController.splllit == 1)
                {
                    GetComponent<SpriteRenderer>().sprite = normal;
                    GetComponent<SpriteRenderer>().color = orang;
                }
                else
                {
                    GetComponent<SpriteRenderer>().sprite = normals1;
                }
                break;
            case 5:
                if (gameController.splllit == 1)
                {
                    GetComponent<SpriteRenderer>().sprite = normal;
                    GetComponent<SpriteRenderer>().color = purp;
                }
                else
                {
                    GetComponent<SpriteRenderer>().sprite = normals2;
                }
                break;
            case 6:
                if (gameController.splllit == 1)
                {
                    GetComponent<SpriteRenderer>().sprite = normal;
                    GetComponent<SpriteRenderer>().color = gren;
                }
                else
                {
                    GetComponent<SpriteRenderer>().sprite = normals3;
                }
                break;
            case 7:
                GetComponent<SpriteRenderer>().sprite = snaaake;
                GetComponent<SpriteRenderer>().color = yel;
                break;
            case 8:
                GetComponent<SpriteRenderer>().sprite = snaaake;
                GetComponent<SpriteRenderer>().color = blu;
                break;
            case 9:
                GetComponent<SpriteRenderer>().sprite = snaaake;
                GetComponent<SpriteRenderer>().color = reeed;
                break;
            case 10:
                if (gameController.splllit == 1)
                {
                    GetComponent<SpriteRenderer>().sprite = snaaake;
                    GetComponent<SpriteRenderer>().color = orang;
                }
                else
                {
                    GetComponent<SpriteRenderer>().sprite = snaaakes1;
                }
                break;
            case 11:
                if (gameController.splllit == 1)
                {
                    GetComponent<SpriteRenderer>().sprite = snaaake;
                    GetComponent<SpriteRenderer>().color = purp;
                }
                else
                {
                    GetComponent<SpriteRenderer>().sprite = snaaakes2;
                } 
                break;
            case 12:
                if (gameController.splllit == 1)
                {
                    GetComponent<SpriteRenderer>().sprite = snaaake;
                    GetComponent<SpriteRenderer>().color = gren;
                }
                else
                {
                    GetComponent<SpriteRenderer>().sprite = snaaakes3;
                }
                break;
            case 13:
                GetComponent<SpriteRenderer>().sprite = balloon;
                GetComponent<SpriteRenderer>().color = yel;
                transform.localScale = new Vector3(0.1F, 0.1F, 0);
                break;
            case 14:
                GetComponent<SpriteRenderer>().sprite = balloon;
                GetComponent<SpriteRenderer>().color = blu;
                transform.localScale = new Vector3(0.1F, 0.1F, 0);
                break;
            case 15:
                GetComponent<SpriteRenderer>().sprite = balloon;
                GetComponent<SpriteRenderer>().color = reeed;
                transform.localScale = new Vector3(0.1F, 0.1F, 0);
                break;
            case 16:
                if (gameController.splllit == 1)
                {
                    GetComponent<SpriteRenderer>().sprite = balloon;
                    GetComponent<SpriteRenderer>().color = orang;
                }
                else
                {
                    GetComponent<SpriteRenderer>().sprite = balloons1;
                }
                transform.localScale = new Vector3(0.1F, 0.1F, 0);
                break;
            case 17:
                if (gameController.splllit == 1)
                {
                    GetComponent<SpriteRenderer>().sprite = balloon;
                    GetComponent<SpriteRenderer>().color = purp;
                }
                else
                {
                    GetComponent<SpriteRenderer>().sprite = balloons2;
                }
                transform.localScale = new Vector3(0.1F, 0.1F, 0);
                break;
            case 18:
                if (gameController.splllit == 1)
                {
                    GetComponent<SpriteRenderer>().sprite = balloon;
                    GetComponent<SpriteRenderer>().color = gren;
                }
                else
                {
                    GetComponent<SpriteRenderer>().sprite = balloons3;
                }
                transform.localScale = new Vector3(0.1F, 0.1F, 0);
                break;
            case 19:
                GetComponent<SpriteRenderer>().sprite = jet;
                GetComponent<SpriteRenderer>().color = yel;
                break;
            case 20:
                GetComponent<SpriteRenderer>().sprite = jet;
                GetComponent<SpriteRenderer>().color = blu;
                break;
            case 21:
                GetComponent<SpriteRenderer>().sprite = jet;
                GetComponent<SpriteRenderer>().color = reeed;
                break;
            case 22:
                if (gameController.splllit == 1)
                {
                    GetComponent<SpriteRenderer>().sprite = jet;
                    GetComponent<SpriteRenderer>().color = orang;
                }
                else
                {
                    GetComponent<SpriteRenderer>().sprite = jets1;
                }
                break;
            case 23:
                if (gameController.splllit == 1)
                {
                    GetComponent<SpriteRenderer>().sprite = jet;
                    GetComponent<SpriteRenderer>().color = purp;
                }
                else
                {
                    GetComponent<SpriteRenderer>().sprite = jets2;
                }
                break;
            case 24:
                if (gameController.splllit == 1)
                {
                    GetComponent<SpriteRenderer>().sprite = jet;
                    GetComponent<SpriteRenderer>().color = gren;
                }
                else
                {
                    GetComponent<SpriteRenderer>().sprite = jets3;
                }
                break;
        }


        #region
        /*
        if (zombCol == 1)
         {
             GetComponent<SpriteRenderer>().color = Color.yellow;
         }
         else if (zombCol == 2)
         {
             GetComponent<SpriteRenderer>().color = Color.blue;
         }
         else if (zombCol == 3)
         {
             GetComponent<SpriteRenderer>().color = Color.red;
         }
         else if (zombCol == 4)
         {
             GetComponent<SpriteRenderer>().color = Color.grey;
         }
         else if (zombCol == 5)
         {
             GetComponent<SpriteRenderer>().color = Color.magenta;
         }
         else if (zombCol == 6)
         {
             GetComponent<SpriteRenderer>().color = Color.green;


         }
         */
        #endregion


    }
    void OnCollisionEnter2D(Collision2D coll)

    {
        if (coll.gameObject.tag == "block")
        {
            Destroy(coll.gameObject);
            Destroy(gameObject);
        }
        if (coll.gameObject.tag == "finalblock")
        {
            coll.gameObject.SetActive(false);

         }
    }
    // Update is called once per frame
    void Update () {
        t = Time.time;
        p = Mathf.Cos(t);
    if (snakemoove)
    {
            if (zombCol >= 7 && zombCol < 13)
            {
                snake = Mathf.Sin(t);
                acc = 0.2f;
            }
            else if (zombCol >= 19 && zombCol < 25)
            {
                transform.localScale = new Vector3(0.4F, 0.4F, 0);
                acc = 0.4f;

                if (p >= 0)
                {
                    snake = 2.7f;
                }
                else
                {
                    snake = -2.7f;
                }
            }
            else if (zombCol >= 13 && zombCol < 19) 
            {
                transform.localScale += new Vector3(0.00028F, 0.00028F, 0);
            }
            else
            {
                
            }
       /* if(zombCol==5)
        {
                snake = Mathf.Clamp(10, -3, -3);
        }*/
           // StartCoroutine(snakecooldown());
    }
       
        m_Rigidbody.velocity = -transform.up * (m_Speed+acc)+transform.right*snake;//downwards+rightwards
        //rb.AddForce(transform.forward * snake*10);
    }
    //IEnumerator snakecooldown()
    //{
    //    snakemoove = false;
    //    yield return new WaitForSeconds(cd);
    //    snakemoove = true;


    //}

}
