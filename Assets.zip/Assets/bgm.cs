﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class bgm : MonoBehaviour {
    public Slider Volume;
    public AudioSource myMusic;
    public Slider Volume2;
    public AudioSource myMusic2;
    public AudioSource myMusic3;
    public AudioSource myMusic4;
    public AudioSource myMusic5;
    // Update is called once per frame
    void Update () {
        myMusic.volume = 2*Volume.value;
        myMusic2.volume = 2*Volume2.value;
        myMusic3.volume = 2 * Volume2.value;
        myMusic4.volume = 2 * Volume2.value;
        myMusic5.volume = 2 * Volume2.value;
    }
}
