﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class bgm : MonoBehaviour {
    static public float value = 0.5f;
    static public float value2 = 0.5f;
    public Slider Volume;
    public AudioSource myMusic;
    public AudioSource myMusicmain;
   // public AudioSource myMusicgg;
    public Slider Volume2;
    public AudioSource myMusic2;
    public AudioSource myMusic3;
    public AudioSource myMusic4;
    public AudioSource myMusic5;
    // Update is called once per frame
    private void Start()
    {
        Volume.value = value;
        Volume2.value = value2;
    }
    void Update () {
        myMusic.volume = 2*Volume.value;
        myMusicmain.volume = 2 * Volume.value;
        //myMusicgg.volume = 2 * Volume.value;
        myMusic2.volume = 2*Volume2.value;
        myMusic3.volume = 2 * Volume2.value;
        myMusic4.volume = 2 * Volume2.value;
        myMusic5.volume = 2 * Volume2.value;
        value = Volume.value;
        value2 = Volume2.value;
        //Debug.Log(value);
        //Debug.Log(value2);
    }
}
